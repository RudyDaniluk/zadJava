package org.example;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

public class SideBar extends JPanel implements ListSelectionListener {

    private final FileHandler fh;   // obsługa plików i katalogów
    private final ContentBox coBox; // obsługa głównego panelu z treścią
    public static DefaultListModel dataModel;   // tablica wpisów (LI)
    private final JList lst;        // kontener Listy (UL/OL)

    SideBar(FileHandler fileHandler, ContentBox cont) {
        this.fh = fileHandler;
        this.coBox = cont;
        this.dataModel = new DefaultListModel();
        this.lst = new JList(dataModel);
        lst.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        lst.setLayoutOrientation(JList.VERTICAL);
        lst.setSelectedIndex(2);	// który wiersz będzie zaznaczony
        lst.setVisibleRowCount(4);	// ile wierszy będzie widocznych
        lst.addListSelectionListener(this);
        // dodanie możliwości przewijania do Listy
        JScrollPane scrLst = new JScrollPane(lst);
        // trybyPrzewijania = JScrollPane.TRYB
        // VERTICAL / HORIZONTAL _SCROLLBAR_ { ALWAYS | AS_NEEDED | NEVER
        //JScrollPane scrLst = new JScrollPane(lst,trybPrzewijania);
        this.add(scrLst);
    }

    public void addToList(String entry){
        dataModel.addElement(entry);
    }
    public void buildFilesList(Set<String> filesList, List<String> filter){
        System.out.println("Building from: "+fh.getDirToRead());
        if(filter.contains("clear")) {
            dataModel.clear();  // wyczyszczenie listy
        }
        if(filter.contains("text")){// zdefiniowanie filtra TYLKO wskazanych plików tekstowych
            filter = Arrays.asList("txt","html","css","js","java","py","php");
        }
        for(String fileName : filesList){
            String ext = fileName.split("\\.")[1];
            if(filter.contains(ext)){// zastosowanie wybranego filtra
                dataModel.addElement(fileName); // dodanie wpisu do Listy plików w panelu bocznym
            }
        }
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        Object src = e.getSource();
        if(src == lst){
            if(e.getValueIsAdjusting() == false){
                if(lst.getSelectedIndex() != -1){ // dokonano wyboru pliku - zazaczono
                    String fileName = dataModel.getElementAt(lst.getSelectedIndex()).toString();
                    fh.setActiveFile(fileName);
                    String content = fh.readFile(fileName);
                    coBox.overWrite(content);// #TODO write to TextArea
                }
            }
        }
    }
}
