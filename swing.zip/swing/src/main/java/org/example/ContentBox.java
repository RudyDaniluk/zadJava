package org.example;

import java.awt.*;
import javax.swing.*;
public class ContentBox {

    JTextArea txa;
    JScrollPane scp;

    ContentBox(){//JTextArea txa){
        this.txa = new JTextArea();//txa;
        scp = new JScrollPane( txa,
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS
        );	// VERTICAL_SCROLLBAR { ALWAYS | AS_NEEDED | NEVER }
        // HORIZONTAL_SCROLLBAR { ALWAYS | AS_NEEDED | NEVER }
        scp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    }

    public void append(String text){
        txa.append(text);	// dopisze nową zawartość do istniejącej
    }
    public void overWrite(String text){
        txa.setText(text); // nadpisze nową zawartością, tę starą
    }
    public String getContent(){
        return txa.getText();
    }

    public Container get(){
        // jeżeli nie rozszeżamy żadnej klasy kontenera
        // to potrzebna jest metoda do zwracania tego kontenera
        return scp;
    }
}
