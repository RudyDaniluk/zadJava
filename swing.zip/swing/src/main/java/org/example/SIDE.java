package org.example;

import javax.swing.*;
import java.awt.*;

public class SIDE {
    JFrame win;
    JPanel pnl, topPnl, sbPnl;
    SIDE(){
    // najpierw MainMenu tutaj i pytanie, czemu są błędy
        win = new JFrame();		// instancja ramki (okna)
        pnl = new JPanel(new BorderLayout());		// koontener na komponenty
        win.setTitle("sIDE");	// tytuł okna
        FileHandler fh = new FileHandler();
    // #1 koontener na Menu+Toolbar
        LayoutManager topLayout = new GridLayout(0,1);
        topPnl = new JPanel();//topLayout);
        topPnl.setLayout(new BoxLayout(topPnl,BoxLayout.Y_AXIS));
        MainMenu m = new MainMenu(win, pnl);//, logr);
    // #3 Lewy Panel
//        txa = new JTextArea();
        ContentBox cont = new ContentBox();// txa);
        sbPnl = new SideBar(fh, cont);//txa);
        fh.getActiveFile();
//        ((SideBar) sbPnl).getActiveFile();
    // zależności SideBar i ContentBox
        ToolBar tlb = new ToolBar(fh, m, sbPnl);//,cont);
        m.setAlignmentX(Component.LEFT_ALIGNMENT);
        tlb.setAlignmentX(Component.LEFT_ALIGNMENT);
        topPnl.add(m);
        topPnl.add(tlb);
        Container scp = cont.get();	// zwraca Textarea
        pnl.add(scp,BorderLayout.CENTER);
    // dodawanie Paneli do Layoutu
        win.add(topPnl, BorderLayout.PAGE_START);
        win.add(sbPnl, BorderLayout.LINE_START);
        win.add(pnl, BorderLayout.CENTER);
        win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        win.pack();	// dopasowuje rozmiar okna do zawartości
        //	win.setSize(640,480);	// rozmiar VGA
        win.setVisible(true);	// uwidocznienie okna
        System.out.print("App");
    }
    public static void main(String[] args) {
        new SIDE();
    }
}