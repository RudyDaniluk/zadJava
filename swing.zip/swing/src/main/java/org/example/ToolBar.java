package org.example;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Set;

public class ToolBar extends JToolBar {
    JButton btnM0, btnM1, btn1, btn2, btn3, btn4, btn5;
    SideBar sbPnl;
    ToolBar(FileHandler fh, JMenuBar mb, JPanel sbPnl) {//}, ContentBox txa){
        JToolBar tlb = this;
        this.sbPnl = (SideBar) sbPnl;
        btnM0 = new JButton("\u2630");// zarzadzanie paskiem Menu głównego
        btnM0.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // JMenuBar ? gdzie ono jest ? w klasie App w linii 14
                mb.setVisible(!mb.isVisible());
            }
        });
        btnM1 = new JButton("\u2756");// undocking Panelu narzędzi
        btnM1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // this ? => ActionListener
                tlb.setFloatable(!tlb.isFloatable());
            }
        });
        btn1 = new JButton("Przeglądaj");
        btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (fh.pickDirectory() == true) {
                    //    ((SideBar)lst).buildFilesList(Arrays.asList("text"));
                    Set<String> files = fh.readDirectory(fh.getDirToRead());
                    ((SideBar) sbPnl).buildFilesList(files, Arrays.asList("clear","text"));
                }
            }
        });
        btn2 = new JButton("Otwórz");
        btn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            /* #TODO zaimplementować (skopiować)
                if(pickFile()==true){
                    readFile();
                }*/
            }
        });
        btn3 = new JButton("Zapisz");
        btn4 = new JButton("Wklej");
        // ikonka z grafiką zamiast tekstu
        btn5 = new JButton(new ImageIcon("katalog/plik.png"));

        // deklarowanie paska narzędziowego
        this.setFloatable(true);    // (od)blokuje przeciąganie panelu
        // ustawia efekt po najechaniu przycisku przez mysz
        this.setRollover(true);    // CSS :hover
        this.add(btnM0);
        this.add(btnM1);
        this.add(btn1);
        this.add(btn2);
        this.addSeparator();
        this.add(btn3);
        this.add(btn4);
        add(btn5);
    }
}