package org.example;

import java.awt.*;
import java.awt.event.*;	// ActionListener
import javax.swing.*;
import java.util.logging.*;
public class MainMenu extends JMenuBar implements ActionListener {

    Logger logr;
    JFrame box;
    JPanel pnl;
    JMenu menu, submenu;
    JMenuItem mi1, mi2, mi3, mi4, mi5, mi6, mi7;

    public MainMenu(JFrame box, JPanel pnl){//, Logger logr
        this.box = box;
        this.pnl = pnl;        //this.logr = logr;
        menu  = new JMenu("Plik");
        submenu  = new JMenu("TESTmenu");
        mi1 = new JMenuItem("Nowy");
        mi2 = new JMenuItem("Otwórz");
        mi3 = new JMenuItem("Zapisz");
        mi4 = new JMenuItem("Opcja 4");
        mi5 = new JMenuItem("Opcja 5");
        mi6 = new JMenuItem("Wyjście");
        mi7 = new JMenuItem("Preferencje");
        mi1.addActionListener(this);        mi2.addActionListener(this);
        mi3.addActionListener(this);        mi4.addActionListener(this);
        mi5.addActionListener(this);        mi6.addActionListener(this);
        mi7.addActionListener(this);
        menu.add(mi1);        menu.add(mi2);        menu.add(mi3);
        submenu.add(mi4);        submenu.add(mi5);
        menu.add(submenu);
        menu.add(mi6);
        menu.add(mi7);
        this.add(menu);
        setAlignmentX(Component.LEFT_ALIGNMENT);        //	logr.info("Utworzono menu w oknie");
    }
    public void actionPerformed(ActionEvent e){
        Object src = e.getSource();
        if( src == mi1 ){
            pnl.setBackground(Color.RED);            //	logr.info("Kliknięto w menu");            //	d.publish(r);
        }
        if( src == mi2 )
            pnl.setBackground(Color.GREEN);
        if( src == mi3 )
            pnl.setBackground(Color.BLUE);
        if( src == mi4 )
            pnl.setBackground(Color.WHITE);
        if( src == mi6 ){
            box.dispose();
        }
        if( src == mi7 ){
            System.out.println("preferencje");;
        }
    }
}
