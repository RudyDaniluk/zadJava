package org.example;

import javax.swing.*;
import javax.swing.filechooser.FileSystemView;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class FileHandler {
    Path dirToRead;
    String activeFile;

    public String getDirToRead() {
        return dirToRead.toString();
    }
    public void setDirToRead(String value) {
        this.dirToRead = Path.of(value);
    }
    public String getActiveFile() {
        return activeFile;
    }
    public void setActiveFile(String activeFile) {
        this.activeFile = activeFile;
    }
    public boolean pickDirectory(){
        boolean open = false;
        JFileChooser pick = new JFileChooser();
        // od katalogu programu: new File(".");
        // od katalogu domowego:
        File startDir = FileSystemView.getFileSystemView().getHomeDirectory();
        pick.setCurrentDirectory(startDir);
        pick.setDialogTitle("Wskaż katalog");
        pick.setFileSelectionMode( JFileChooser.DIRECTORIES_ONLY);
        pick.setAcceptAllFileFilterUsed(false);
        if( pick.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            this.dirToRead = pick.getSelectedFile().toPath();
            open = true;
            System.out.println("DIR opened: "+dirToRead);
        } else {
            open = false;
            System.out.println("Błąd otwierania katalogu");
        }
        return open;
    }
    public Set<String> readDirectory(String dir){
        Set<String> files = new HashSet<>();
        try {
            DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get(dir));
            for( Path path : stream) {
                if( !Files.isDirectory(path) ){
                    files.add(path.getFileName().toString());
                }
            }
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        return null;
    }
    public String readFile(String input){
        String out = "";
        String pathFile = this.dirToRead+"/"+input;
        File file = new File(pathFile);
        try {
            Scanner reader = new Scanner(file);
            while(reader.hasNextLine()){// odczytuj plik tak długo, aż osiągniesz koniec pliku
                out+= reader.nextLine();// odczyt każdej linii
                out+= "\r\n";   // znaki nowej linii
            }
        } catch (FileNotFoundException e) {// plik nie istnieje
            System.out.println("Brak pliku: "+input);
            throw new RuntimeException(e);
        }
        return out;
    }
}
